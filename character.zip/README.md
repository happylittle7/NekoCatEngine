# NekoCatEngine
A C based visual novel Engine

