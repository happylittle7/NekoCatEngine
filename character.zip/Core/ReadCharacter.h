#pragma once
#include "../Library/toml.h"
#include <stdio.h>

void ReadCharacter();